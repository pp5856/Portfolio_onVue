<template>
  <div>
    <h1><strong style="color: green">양태원</strong>의 Portfolio</h1>
  </div>
</template>

<script>
//Vue.js 컴포넌트를 export합니다.
export default {
  name: 'NameCard',
};
</script>

<style scoped>
div {
  text-align: left;
  border-bottom: 1px solid gray;
}
</style>
